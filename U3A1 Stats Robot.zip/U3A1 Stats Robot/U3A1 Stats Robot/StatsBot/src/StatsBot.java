import becker.robots.*;

public class StatsBot extends RobotSE {
    // Private instance variables to track statistics
    private int eastMoves;
    private int westMoves;
    private int northMoves;
    private int southMoves;
    private int thingsPicked;
    private int intersectionsVisited;
    private int wallHits;
    private int totalMovesAttempted;
    private final int targetThings = 6;

    // Constructor
    public StatsBot(City city, int avenue, int street, Direction direction) {
        super(city, avenue, street, direction);
        resetCounters();
    }

    private void resetCounters() {
        eastMoves = 0;
        westMoves = 0; 
        northMoves = 0;
        southMoves = 0;
        thingsPicked = 0;
        intersectionsVisited = 0;
        wallHits = 0;
        totalMovesAttempted = 0;
    }

    public void navigateUntilStuck() {
        final int MAX_MOVES = 800;
        
        while (totalMovesAttempted < MAX_MOVES && thingsPicked < targetThings) {
            totalMovesAttempted++;
            
            // Try to follow right wall
            this.turnRight();
            if (attemptMoveWithPickup(this.getDirection())) {
                continue;
            }
            
            this.turnLeft();
            if (attemptMoveWithPickup(this.getDirection())) {
                continue;
            }
            
            this.turnLeft();
            if (attemptMoveWithPickup(this.getDirection())) {
                continue;
            }
            
            this.turnLeft(); // Now facing original direction
            if (!attemptMoveWithPickup(this.getDirection())) {
                break; // Completely stuck
            }
            
            // Early exit if target reached
            if (thingsPicked >= targetThings) {
                System.out.println("Collected " + targetThings + " objects - mission complete!");
                break;
            }
        }
    }

    private boolean attemptMoveWithPickup(Direction dir) {
        // Face the desired direction
        while (this.getDirection() != dir) {
            this.turnLeft();
        }
        
        // Check if front is clear
        if (this.frontIsClear()) {
            this.move();
            recordMove(dir);
            checkAndPickThing(); // Always check after moving
            return true;
        } else {
            wallHits++;
            return false;
        }
    }

    private void recordMove(Direction dir) {
        if (dir == Direction.EAST) eastMoves++;
        else if (dir == Direction.WEST) westMoves++;
        else if (dir == Direction.NORTH) northMoves++;
        else if (dir == Direction.SOUTH) southMoves++;
        intersectionsVisited++;
    }

    private void checkAndPickThing() {
        // Check multiple times to ensure pickup
        if (this.canPickThing()) {
            this.pickThing();
            thingsPicked++;
            System.out.println("Picked up object! Total: " + thingsPicked);
        }
    }

    public void displayStats() {
        int totalMoves = eastMoves + westMoves + northMoves + southMoves;
        
        System.out.println("\n=== Movement Statistics ===");
        System.out.println("Total moves attempted: " + totalMovesAttempted);
        System.out.println("Successful moves: " + totalMoves);
        System.out.println("Wall hits: " + wallHits);
        System.out.println("\n=== Movement Probabilities ===");
        System.out.printf("East: %.2f%%\n", totalMoves > 0 ? (double)eastMoves / totalMoves * 100 : 0);
        System.out.printf("West: %.2f%%\n", totalMoves > 0 ? (double)westMoves / totalMoves * 100 : 0);
        System.out.printf("North: %.2f%%\n", totalMoves > 0 ? (double)northMoves / totalMoves * 100 : 0);
        System.out.printf("South: %.2f%%\n", totalMoves > 0 ? (double)southMoves / totalMoves * 100 : 0);
        System.out.println("\n=== Collection Statistics ===");
        System.out.printf("Pickup Probability: %.2f%%\n", intersectionsVisited > 0 ? (double)thingsPicked / intersectionsVisited * 100 : 0);
        System.out.println("Things collected: " + thingsPicked + "/" + targetThings);
        System.out.println("Intersections visited: " + intersectionsVisited);
    }

    // Accessor methods
    public int getEastMoves() { return eastMoves; }
    public int getWestMoves() { return westMoves; }
    public int getNorthMoves() { return northMoves; }
    public int getSouthMoves() { return southMoves; }
    public int getThingsPicked() { return thingsPicked; }
    public int getIntersectionsVisited() { return intersectionsVisited; }
    public int getWallHits() { return wallHits; }
    public int getTotalMovesAttempted() { return totalMovesAttempted; }
}