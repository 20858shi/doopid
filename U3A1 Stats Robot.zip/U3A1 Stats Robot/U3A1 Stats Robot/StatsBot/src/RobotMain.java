import becker.robots.*;

public class RobotMain {
    public static void main(String[] args) {
        // Load the maze world
        City mazeCity = new City("A1Maze.txt");
        
        // Create StatsBot starting at avenue 4, street 4, facing North
        StatsBot statsBot = new StatsBot(mazeCity, 4, 4, Direction.NORTH);
        
        // Add a delay so we can see the robot's movements
        statsBot.setSpeed(10);
        
        try {
            // Navigate through the maze until stuck
            System.out.println("Starting maze navigation...");
            statsBot.navigateUntilStuck();
            System.out.println("Maze navigation completed!");
        } catch (Exception e) {
            System.out.println("Error during navigation: " + e.getMessage());
        }
        
        // Display the statistics after completing the maze
        statsBot.displayStats();
    }
}